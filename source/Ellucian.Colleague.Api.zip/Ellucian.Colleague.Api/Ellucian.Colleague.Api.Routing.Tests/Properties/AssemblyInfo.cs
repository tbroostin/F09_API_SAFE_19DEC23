using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ellucian.Colleague.Api.Routing.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ellucian")]
[assembly: AssemblyProduct("Ellucian.Colleague.Api.Routing.Tests")]
[assembly: AssemblyCopyright("Copyright 2019 Ellucian Company L.P. and its affiliates")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("5cf89e9c-80ac-48ea-a8d7-b3604f2a8f91")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.26.0.0")]
[assembly: AssemblyFileVersion("1.26.0.8")]

﻿// Copyright 2017 Ellucian Company L.P. and its affiliates.

using System;

namespace Ellucian.Colleague.Domain.FinancialAid
{
    [Serializable]
    public static class FinancialAidPermissionCodes
    {
              
    }
}
